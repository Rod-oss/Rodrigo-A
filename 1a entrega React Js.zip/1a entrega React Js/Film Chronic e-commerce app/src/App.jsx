import { useState } from 'react'
import logo from './assets/logo.png'
import './App.css';
import NavBar from './assets/Components/NavBar';
import ItemListContainer from './assets/Components/ItemListContainer';

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <div>
      <a><img src={logo} className="logo" alt="Logo de Film Chronic" /></a>
      </div> 
      <div>
        <NavBar/>
       
        <ItemListContainer/>            
      </div> 
      <h1>Film Chronic</h1>
      
    </>
  )
}

export default App
