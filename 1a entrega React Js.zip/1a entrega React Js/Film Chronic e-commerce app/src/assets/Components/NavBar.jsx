import CartWidget from './CartWidget';

//const cargarImagen = require.context('./assets/FClogo.png', true);

const NavBar = () => {
    //const logo = cargarImagen('./FClogo.png')
    return (
      <nav>
        <img src= {'./assets/logo.png'} alt="Logo de la tienda" />
        <div>
        <ul>
          <li><a href="#">Inicio</a></li>
          <li><a href="#">Productos</a></li>
          <li><a href="#">Contacto</a></li>
        </ul>
        </div>

        <div>
         <CartWidget> </CartWidget>
        </div>
      </nav>
    );
  };
  
  export default NavBar;