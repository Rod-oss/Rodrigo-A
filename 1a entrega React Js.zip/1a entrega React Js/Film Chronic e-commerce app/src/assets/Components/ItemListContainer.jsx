const ItemListContainer = ({message}) => {
    return (
      <div>
        <h1>Bienvenido a nuestra tienda</h1>
        <p>{message}</p>
        <ul>
          <li>Producto 1</li>
          <li>Producto 2</li>
          <li>Producto 3</li>
        </ul>
      </div>
    );
  };
  
  ItemListContainer.defaultProps = {
    message: 'Agrega productos al carrito',
  };
  
  export default ItemListContainer;