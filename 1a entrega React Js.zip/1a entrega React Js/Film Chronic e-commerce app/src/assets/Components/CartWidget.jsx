icon: 'assets/cart.png'

const CartWidget = () => { 

    return (
        <div>
          <img src={'./assets/cart.png'} alt="Carrito de compras" /> 
          0
            </div>
      );
    }

export default CartWidget; 